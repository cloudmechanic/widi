An icon group is primarily used in the anchor of a page that can change views or be sorted. It usually contains stateful icon buttons.
