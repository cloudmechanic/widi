A prompt for touch is a notification modal that appears in the small form factor.
