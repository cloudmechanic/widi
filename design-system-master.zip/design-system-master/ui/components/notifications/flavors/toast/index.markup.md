When notifications are used in modals, they should be placed in the
`.{{cssPrefix}}modal__header` so that they can easily be seen in modals with
scrolling content. This modal contains a notifications > toast.
