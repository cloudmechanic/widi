An action overflow for touch is the list of actions that are usually secondary or tertiary to a task. These are usually utility actions like edit, delete, etc. This is specifically for touch devices.
