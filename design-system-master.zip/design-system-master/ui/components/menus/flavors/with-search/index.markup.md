When you have a list that requires search functionality because you anticipate it being very long, please use this variation.
