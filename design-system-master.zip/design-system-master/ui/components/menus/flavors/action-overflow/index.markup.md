An action overflow is a list of actions that are usually secondary or tertiary to a task. These are usually utility actions like edit, delete, etc.
