To vertically stack `<label>` and `<input>` pairs, place `.{{cssPrefix}}form--stacked` on the wrapper of the form for optimal spacing.
