You can style the HTML `<textarea>` element to align with the Salesforce brand by using the class `.{{cssPrefix}}textarea` on the `<textarea>` element.
