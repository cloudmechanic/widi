The Edit Dialog is a form that appears as a modal for mobile devices.
