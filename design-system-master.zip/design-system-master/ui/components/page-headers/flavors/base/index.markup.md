The page header is a masthead that contains the Title of the page, and supporting details. For large form factors, it may include actions.
